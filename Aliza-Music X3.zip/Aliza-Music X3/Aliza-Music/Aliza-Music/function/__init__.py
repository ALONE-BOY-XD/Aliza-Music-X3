from AdityaPlayer.function.admins import admins, get, set

__all__ = ["set", "get", "admins"]
